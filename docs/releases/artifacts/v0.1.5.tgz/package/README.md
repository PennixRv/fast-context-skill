# `@pennixrv/fast-context-skill`

An on-demand Agent Skill and local CLI that asks Windsurf Devstral for bounded
semantic code-search candidates. Local `rg` and CodeGraph remain the default
path; this helper is for genuinely unknown locations or vague legacy behavior.

## Use

Pass an existing project directory. An explicit key remains supported for the
current process:

```bash
WINDSURF_API_KEY='provided-out-of-band' \
  npx --yes @pennixrv/fast-context-skill \
  --project "/absolute/path/to/project" \
  --query "Where is the legacy import flow implemented?"
```

On Linux/WSL, when the current user has already completed Devin CLI login, the
same command may omit `WINDSURF_API_KEY`. The runtime then starts a bounded,
no-shell helper that reads only the fixed Devin CLI credentials file for that
user. It rejects symbolic links, oversized files, unknown fields and unsupported
formats, does not scan desktop state databases, and never exposes the token in
arguments, output, logs, or persistent state. Explicit `WINDSURF_API_KEY`
always has priority.

The accepted options are `--project`, `--query`, bounded `--max-results`,
repeatable relative `--deny`, standalone `--no-external`, and standalone
`--help`. `--no-external` exits with `FC_EXTERNAL_DISABLED` before inspecting
credentials, importing the remote core, or opening a network request. Missing
credentials produce `FC_KEY_MISSING`; `401/403`, timeout, transport, `5xx`,
and malformed protocol responses use distinct fixed `FC_*` diagnostics. The
CLI never prints, stores, or logs credentials. It rejects metadata, secrets,
generated output, and paths outside the canonical project root before any
remote request.

Use the returned paths only as hints and verify them with local tools. A single
JSON result is emitted on stdout; fixed `FC_*` diagnostics are emitted on
stderr. No MCP server, registration, approval, whitelist, or global agent
configuration is required.

## Bounded coverage

Each invocation uses one monotonic deadline and one shared resource budget for
authentication, protocol requests, directory traversal, glob matching, `rg`
subprocesses, tool commands, and model rounds. Local enumeration limits visited
entries, directories, depth, files, matches, and output bytes. Child processes
run without a shell and are terminated and reaped when the caller cancels or
the deadline expires.

Successful JSON uses `status: "complete"` or `status: "truncated"` and includes
local `coverage` counts, fixed reasons, and continuation information when
available. `complete` means the search exhausted the paths that PathGuard was
allowed to inspect within the named limits. It does not include denied paths
and does not prove semantic correctness or unrestricted whole-repository
coverage. `truncated` means the returned candidates may be incomplete; it is
never rendered as a conclusive `(no matches)` result.

Candidate projection has three distinct trust boundaries. PathGuard first
revalidates canonical containment, deny rules, and symlink escapes. It then
opens the approved file and accepts only a 1-based range of at most 200 lines
that exists in one unchanged file version; empty files, EOF overflow, oversized
ranges, and files changed during validation are dropped without clamping.
Finally, callers must still inspect the returned source and decide whether it
actually satisfies the requested behavior. The fixed
`reason: "local_range_validated"` describes local path/range validation only,
not semantic correctness.

## Development

All checks are offline and use temporary fixtures or injected request runners:

```bash
npm test
npm run verify:provenance
npm run pack:check
npm pack --dry-run --json --ignore-scripts
node scripts/release/build-package.mjs --output dist/package-check
```

These commands do not call Windsurf, npm publication, GitHub, or any real
credential source.

The `test`, `release`, `release:verify`, and packaging-check scripts belong to
the source repository's maintainer workflow. They are intentionally omitted
from the installed consumer manifest; installation exposes only the runtime
CLI and Skill assets.

## Attribution

The upstream MIT license is preserved at `scripts/lib/LICENSE.fast-context-mcp`.
See `NOTICE.md` and [`references/source-provenance.json`](references/source-provenance.json)
for the public shipped-file classification and digests. The projection is
included in the npm tarball; the full maintainer provenance remains source-only.
